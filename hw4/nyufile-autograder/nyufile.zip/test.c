#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main() {
   int fd = open("fat32.disk", O_RDONLY);  // open the file in read-only mode
   off_t offset = 10;  // move the file pointer 10 bytes from the beginning of the file
   off_t new_offset = lseek(fd, offset, SEEK_SET);  // move the file pointer using lseek
   if (new_offset == -1) {
      perror("lseek error");  // check if lseek() failed
   } else {
      printf("New file offset is: %ld\n", new_offset);  // print the new file offset
   }
   close(fd);  // close the file
   return 0;
}
