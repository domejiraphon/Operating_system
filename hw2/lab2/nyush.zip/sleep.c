#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(){
  while(1)
    sleep(3);
  return 0;
}