#ifndef _UTILS_H_
#define _UTILS_H_

void free_copied_args(char **args, ...);
int getLengthDoublePtr(char **ptr); 
#endif
