// C program to implement cond(), signal()
// and wait() functions
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
	printf("Helllo \n");
  fflush(stdout);
    int ret = fork();
  printf("123 \n");

	return 0;
}
