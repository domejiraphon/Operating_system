#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>

int main() {
    int fd[2];
    char buf[100];
    if (pipe(fd) == -1) {
        perror("pipe");
        return 1;
    }
    

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }
    
    if (pid == 0) {
        // Child process
        close(1);  // Close the standard output
        dup2(fd[1], 1);  // Redirect the standard output to the write end of the pipe
        close(fd[0]);

        char *args[] = { "/bin/ls", "-l", NULL };
        execv(args[0], args);
        perror("execv");
        return 1;
    } else {
        // Parent process
        close(fd[1]);  // Close the write end of the pipe
        dup2(fd[0], 0);
        close(fd[0]);
        //ssize_t n = read(fd[0], buf, 100);
       
        char *args[] = { "wc", "-l", NULL };
        execvp(args[0], args);
        //printf("Parent process received: %s\n", buf);
        close(fd[0]);
    }

    wait(NULL);
    return 0;
}
